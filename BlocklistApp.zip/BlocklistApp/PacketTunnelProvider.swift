//
//  PacketTunnelProvider.swift
//  PacketTunnel
//
//  Created by Rohan Sakhare on 25/07/24.
//

import NetworkExtension

class PacketTunnelProvider: NEPacketTunnelProvider {
    
    override func startTunnel(options: [String : NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        // Setup network configurations and start the tunnel
        let networkSettings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        
        // Configure DNS settings
        let dnsSettings = NEDNSSettings(servers: ["8.8.8.8", "8.8.4.4"])
        networkSettings.dnsSettings = dnsSettings
        
        // Configure IP settings
        let ipSettings = NEIPv4Settings(addresses: ["192.0.2.1"], subnetMasks: ["255.255.255.0"])
        ipSettings.includedRoutes = [NEIPv4Route.default()]
        networkSettings.ipv4Settings = ipSettings
        
        setTunnelNetworkSettings(networkSettings) { error in
            if let error = error {
                completionHandler(error)
                return
            }
            
            self.startCapture()
            completionHandler(nil)
        }
    }
    
    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        // Stop the tunnel and clean up
        completionHandler()
    }
    
    private func startCapture() {
        packetFlow.readPackets { packets, protocols in
            for packet in packets {
                // Inspect packets here and block if they match blocklist
                // For simplicity, assume all packets are to be blocked
                self.packetFlow.writePackets([packet], withProtocols: protocols)
            }
            self.startCapture()
        }
    }
}
